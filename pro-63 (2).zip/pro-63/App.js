import React from 'react'
import { Text, View, StyleSheet,TouchableOpacity,TextInput } from 'react-native';
import {Header} from 'react-native-elements'
import dictionary from './db'

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default class App extends React.Component {
  render(){
    return (
    <View style={styles.container}>
     <TextInput
     style = {styles.inputBox}
     onChangeText = {text => {
       this.setState({
         text: text,
         isSearchPressed : false,
         word: " Loading...",
         lexicalCategory: '',
         examples: [],
         defination: ""
       })
     }}
     value = {this.state.text}
     />
     <TouchableOpacity
        style= {styles.searchButton}
        onPress = {() => {
          this.setState({isSearchPressed: true})
          this.getWorld(this.state.text)
        }}>
     </TouchableOpacity>
    </View>
  }
    );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  inputBoxContainer: {
    flex: 0.3,
    alignItems: 'center',
    jusifyContent: 'center',
  },
  inputBox: {
    width: '80%',
    alignSelf: 'center',
    height: 40
  }
});
